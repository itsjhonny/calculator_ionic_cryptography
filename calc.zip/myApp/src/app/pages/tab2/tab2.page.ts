import { Component } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { listOptionsCalc } from "./Calc_Modals/calc_Modal";

import { Platform, AlertController, ToastController } from "@ionic/angular";
import { SecureStorage } from "src/app/services/storage.services";

@Component({
  selector: "app-tab2",
  templateUrl: "tab2.page.html",
  styleUrls: ["tab2.page.scss"]
})
export class Tab2Page {
  currentSelected: Number = null;
  inputNumbers: any;
  messageInputNumber1 = "";
  messageInputNumber2 = "";

  isErrorInputNumber1 = false;
  isErrorInputNumber2 = false;

  listOptionsCalc = new listOptionsCalc().listOptionsCalc;

  constructor(
    private platform: Platform,
    formBuilder: FormBuilder,
    private alertController: AlertController,
    private secureStorage: SecureStorage,
    public toastController: ToastController
  ) {
    this.inputNumbers = formBuilder.group({
      inputNumber1: [
        "",
        Validators.compose([
          Validators.minLength(1),
          Validators.pattern("^[0-9]*$"),
          Validators.required
        ])
      ],
      inputNumber2: [
        "",
        Validators.compose([
          Validators.minLength(1),
          Validators.pattern("^[0-9]*$"),
          Validators.required
        ])
      ]
    });

    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {});
  }

  onItemClicked(option, idx) {
    this.currentSelected = idx;
  }

  valideteForm() {
    let { inputNumber1, inputNumber2 } = this.inputNumbers.controls;

    //Numero 1
    if (!this.inputNumbers.valid) {
      if (!inputNumber1.valid) {
        this.isErrorInputNumber1 = true;
        this.messageInputNumber1 = "Número inválido";
      } else {
        this.messageInputNumber1 = "";
      }

      //Numero 2
      if (!inputNumber2.valid) {
        this.isErrorInputNumber2 = true;
        this.messageInputNumber2 = "Número inválido";
      } else {
        this.messageInputNumber2 = "";
      }
    } else {
      alert("Resultado: ");
    }
  }

  //TESTE CRIPTOGRAFIA
  //para verificar o storage no browser: clique em inspecionar no browser -> appliccations -> IndexedDB
  // -> ionicStorage -> _ionickv

  async presentAlertPrompt() {
    const alert = await this.alertController.create({
      header: "Salvar informacões criptografadas",
      inputs: [
        {
          name: "name",
          type: "text",
          placeholder: "Digite um nome"
        },
        {
          name: "key",
          type: "password",
          placeholder: "Digite uma senha"
        }
      ],
      buttons: [
        {
          text: "Cancel",
          role: "cancel",
          cssClass: "secondary",
          handler: () => {
            console.log("Confirm Cancel");
          }
        },
        {
          text: "Salvar",
          handler: data => {
            this.secureStorage.key = data.key;
            this.secureStorage.setStorage(data.name).then(() => {
              this.presentToastWithOptions(null, null);
            });
          }
        }
      ]
    });

    await alert.present();
  }

  async presentToastWithOptions(header, mensage) {
    const toast = await this.toastController.create({
      header: "Dados salvos com sucesso",
      message: "Vá até a aba Registros e selecione um",
      position: "top",
      buttons: [
        {
          side: "start",
          icon: "lock",
          text: "Ok",
          handler: () => {
            console.log("");
          }
        }
      ]
    });
    toast.present();
  }
}
