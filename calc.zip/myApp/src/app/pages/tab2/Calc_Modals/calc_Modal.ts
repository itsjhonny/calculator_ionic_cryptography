export class listOptionsCalc {
  listOptionsCalc = [
    {
      description: "Acrescentar",
      icon: "add-circle",
      value: "increment"
    },
    {
      description: "Subtrair",
      icon: "remove-circle",
      value: "subtract"
    },
    {
      description: "Multiplicar",
      icon: "close-circle",
      value: "multiply"
    },
    {
      description: "Dividir",
      icon: "contrast",
      value: "divide"
    }
  ];
}

class ActionCalculate {
  increment(inputNumber1, inputNumber2) {
    try {
      return inputNumber1 + inputNumber2;
    } catch (error) {
      console.log("erro ActionCalculate.increment " + error);
    }
  }

  subtract(inputNumber1, inputNumber2) {
    try {
      return inputNumber1 - inputNumber2;
    } catch (error) {
      console.log("erro ActionCalculate.decrement " + error);
    }
  }
}
