import { Component } from "@angular/core";
import { Platform } from "@ionic/angular";

@Component({
  selector: "app-tab1",
  templateUrl: "tab1.page.html",
  styleUrls: ["tab1.page.scss"]
})
export class Tab1Page {
  constructor(private platform: Platform) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.toggleDarkTheme();
    });
  }

  toggleDarkTheme() {
    const toggle: any = document.querySelector("#themeToggle");

    // Listen for the toggle check/uncheck to toggle the dark class on the <body>
    toggle.addEventListener("ionChange", (ev: any) => {
      document.body.classList.toggle("dark", ev.detail.checked);
    });

    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)");

    // Listen for changes to the prefers-color-scheme media query
    prefersDark.addListener(e => checkToggle(e.matches));

    // Called when the app loads
    function loadApp() {
      checkToggle(prefersDark.matches);
    }

    // Called by the media query to check/uncheck the toggle
    function checkToggle(shouldCheck) {
      toggle.checked = shouldCheck;
    }
  }
}
