import { Component } from "@angular/core";
import { AlertController, ToastController } from "@ionic/angular";
import { SecureStorage } from "src/app/services/storage.services";

@Component({
  selector: "app-tab3",
  templateUrl: "tab3.page.html",
  styleUrls: ["tab3.page.scss"]
})
export class Tab3Page {
  constructor(
    public toastController: ToastController,
    private alertController: AlertController,
    private secureStorage: SecureStorage
  ) {}

  async getUserData(nameUser) {
    const alert = await this.alertController.create({
      header: "Salvar informacões criptografadas",
      inputs: [
        {
          name: "key",
          type: "password",
          placeholder: "Digite uma senha"
        }
      ],
      buttons: [
        {
          text: "Cancel",
          role: "cancel",
          cssClass: "secondary",
          handler: () => {
            console.log("Confirm Cancel");
          }
        },
        {
          text: "Visualizar",

          handler: data => {
            this.secureStorage
              .getStorage(data.key)
              .then(decryptedData => {
                this.presentToastWithOptions(nameUser, decryptedData);
              })
              .catch(err => {
                this.presentToastWithOptions(nameUser, "Senha incorreta");
              });
          }
        }
      ]
    });

    await alert.present();
  }

  async presentToastWithOptions(nameUser, mensage) {
    const toast = await this.toastController.create({
      header: "Dados: " + nameUser,
      message: JSON.stringify(mensage),
      position: "middle",
      buttons: [
        {
          side: "start",
          icon: "unlock",
          text: "Ok",
          handler: () => {
            console.log("");
          }
        }
      ]
    });
    toast.present();
  }
}
