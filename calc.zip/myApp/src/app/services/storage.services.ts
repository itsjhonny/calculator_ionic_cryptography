import { NgModule, Injectable } from "@angular/core";
import { Storage } from "@ionic/storage";
import CryptoJS from "crypto-js";

@Injectable()
export class SecureStorage {
  key = "joaotestes";
  localData: Object = {};
  storekey: string = "secretdata";

  constructor(private storage: Storage) {}

  getStorage(key) {
    return this.storage.ready().then(() => {
      return this.storage.get(this.storekey).then(data => {
        this.localData = {};
        if (data != null) {
          this.localData = this.decrypt(key, data);
          return this.localData;
        } else return false;
      });
    });
  }

  encrypt(data) {
    return CryptoJS.AES.encrypt(JSON.stringify(data), this.key).toString();
  }

  decrypt(key, data) {
    let bytes = CryptoJS.AES.decrypt(data, key);
    return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
  }

  setOnly(key, data) {
    this.localData[key] = data;
    return Promise.resolve(true);
  }

  getLocalData(key) {
    if (this.localData[key]) return Promise.resolve(this.localData[key]);
    else return Promise.resolve(null);
  }

  changeSecret(newsecret) {
    this.key = newsecret;
    return this.storage.ready().then(() => {
      return this.storage.set(
        this.storekey,
        this.encrypt(this.localData ? this.localData : "")
      );
    });
  }

  async setStorage(data) {
    this.setOnly(this.key, data);
    return await this.storage.ready().then(() => {
      return this.storage.set(
        this.storekey,
        this.encrypt(this.localData ? this.localData : "")
      );
    });
  }
}
